from box_sdk_gen.internal.base_object import BaseObject


class AiExtractResponse(BaseObject):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
