import base64
import datetime
import hashlib
import os
import uuid
import time
from enum import Enum
from io import SEEK_CUR, SEEK_END, SEEK_SET, BufferedIOBase, BytesIO
from typing import Any, Callable, Dict, Iterable, Optional, TypeVar

try:
    import jwt
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import serialization
except ImportError:
    jwt, default_backend, serialization = None, None, None

from .base_object import BaseObject
from ..serialization.json.json_data import sd_to_json
from ..serialization.json.serializer import serialize
from .null_value import null

ByteStream = BufferedIOBase
Buffer = bytes


class ResponseByteStream(ByteStream):
    def __init__(self, request_iterator):
        self._iterator = request_iterator
        self._buffer = b''
        self._position = 0
        self._eos = False

    def _read_from_iterator(self, size):
        """
        Read up to `size` bytes from the iterator into the buffer
        :param size: Number of bytes to read. If None, read the entire stream.
        """
        if self._eos:
            return

        while len(self._buffer) < size:
            try:
                chunk = next(self._iterator)
                self._buffer += chunk
            except StopIteration:
                self._eos = True
                break

    def tell(self):
        """
        Returns the current position in the stream
        :return:
        """
        return self._position

    def read(self, size=None):
        """
        Reads up to `size` bytes from the stream
        :param size: Read up to `size` bytes from the stream. If None read the entire stream.
        :return: Bytes read from the stream
        """
        if size is None:
            # Read everything remaining in the stream.
            result = self._buffer + b''.join(self._iterator)
            self._buffer = b''
            self._position += len(result)
            self._eos = True
            return result

        self._read_from_iterator(size)
        result = self._buffer[:size]
        self._buffer = self._buffer[size:]
        self._position += len(result)
        return result

    def seek(self, position, whence=SEEK_SET):
        """
        Move the stream to given position
        :param position: Position to move to
        :param whence: One of SEEK_SET = 0, SEEK_CUR = 1 or SEEK_END = 2
        :return: The new position in the stream
        """
        if whence == SEEK_SET:
            if position < self._position:
                raise ValueError('Cannot seek backwards in a stream')
            self.read(position - self._position)
        elif whence == SEEK_CUR:
            self.read(position)
        elif whence == SEEK_END:
            raise NotImplementedError('SEEK_END is not supported for streams')
        else:
            raise ValueError('Invalid value for `whence`')

        return self._position


def get_env_var(name: str) -> str:
    return os.getenv(name)


def get_uuid() -> str:
    return str(uuid.uuid1())


def decode_base_64(value: str) -> str:
    return base64.b64decode(value).decode()


def generate_byte_buffer(size: int) -> Buffer:
    return Buffer(os.urandom(size))


def generate_byte_stream_from_buffer(buffer: Buffer) -> ByteStream:
    return BytesIO(buffer)


def generate_byte_stream(size: int) -> ByteStream:
    return BytesIO(os.urandom(size))


def buffer_equals(buffer1: Buffer, buffer2: Buffer) -> bool:
    return buffer1 == buffer2


def buffer_length(buffer: Buffer) -> int:
    return len(buffer)


def decode_base_64_byte_stream(value: str) -> ByteStream:
    return BytesIO(base64.b64decode(value))


def string_to_byte_stream(value: str) -> ByteStream:
    return BytesIO(bytes(value, 'utf-8'))


def read_byte_stream(byte_stream: ByteStream) -> Buffer:
    return Buffer(byte_stream.read())


def prepare_params(map: Dict[str, Optional[str]]) -> Dict[str, str]:
    return {k: v for k, v in map.items() if v is not None}


def to_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime.datetime):
        return date_time_to_string(value)
    if isinstance(value, datetime.date):
        return date_to_string(value)
    if (
        isinstance(value, BaseObject)
        or isinstance(value, list)
        and len(value) >= 1
        and isinstance(value[0], BaseObject)
    ):
        return ''.join(sd_to_json(serialize(value)).split())
    if isinstance(value, list):
        return ','.join(map(to_string, value))
    if isinstance(value, Enum):
        return value.value
    return str(value)


class HashName(str, Enum):
    SHA1 = 'sha1'


class Hash:
    def __init__(self, algorithm: HashName):
        self.algorithm = algorithm
        self.hash = hashlib.sha1()

    def update_hash(self, data: Buffer):
        self.hash.update(data)

    def digest_hash(self, encoding):
        return base64.b64encode(self.hash.digest()).decode("utf-8")


def hex_to_base_64(data: hex):
    return base64.b64encode(bytes.fromhex(data)).decode()


T = TypeVar('T')
Iterator = Iterable[T]
Accumulator = TypeVar('Accumulator')


def iterate_chunks(
    stream: ByteStream, chunk_size: int, file_size: int
) -> Iterable[ByteStream]:
    stream_is_finished = False
    while not stream_is_finished:
        copied_length = 0
        chunk = b''
        while copied_length < chunk_size:
            bytes_read = stream.read(chunk_size - copied_length)
            if bytes_read is None:
                # stream returns none when no bytes are ready currently but there are
                # potentially more bytes in the stream to be read.
                continue
            if not bytes_read:
                # stream is exhausted.
                stream_is_finished = True
                break
            chunk += bytes_read
            copied_length += len(bytes_read)
        if chunk:
            yield BytesIO(chunk)


def reduce_iterator(
    iterator: Iterator,
    reducer: Callable[[Accumulator, T], Accumulator],
    initial_value: Accumulator,
) -> Accumulator:
    result = initial_value

    for item in iterator:
        result = reducer(result, item)

    return result


def read_text_from_file(file_path: str) -> str:
    with open(file_path, 'r') as file:
        return file.read()


def is_browser() -> bool:
    return False


def get_epoch_time_in_seconds() -> int:
    return int(time.time())


def get_value_from_object_raw_data(obj: BaseObject, key: str) -> Any:
    return obj.raw_data.get(key, None)


class JwtAlgorithm(str, Enum):
    HS256 = 'HS256'
    HS384 = 'HS384'
    HS512 = 'HS512'
    RS256 = 'RS256'
    RS384 = 'RS384'
    RS512 = 'RS512'
    ES256 = 'ES256'
    ES384 = 'ES384'
    ES512 = 'ES512'
    PS256 = 'PS256'
    PS384 = 'PS384'
    PS512 = 'PS512'
    none = 'none'


class JwtSignOptions(BaseObject):
    def __init__(
        self,
        algorithm: JwtAlgorithm,
        headers: Dict[str, str] = None,
        audience: Optional[str] = None,
        issuer: Optional[str] = None,
        subject: Optional[str] = None,
        jwtid: Optional[str] = None,
        keyid: Optional[str] = None,
        **kwargs
    ):
        super().__init__(**kwargs)
        if headers is None:
            headers = {}
        self.algorithm = algorithm
        self.headers = headers
        self.audience = audience
        self.issuer = issuer
        self.subject = subject
        self.jwtid = jwtid
        self.keyid = keyid


class JwtKey(BaseObject):
    def __init__(self, key: str, passphrase: str, **kwargs):
        super().__init__(**kwargs)
        self.key = key
        self.passphrase = passphrase


def encode_str_ascii_or_raise(passphrase: str) -> bytes:
    try:
        return passphrase.encode('ascii')
    except UnicodeError as unicode_error:
        raise TypeError(
            "private_key and private_key_passphrase must contain binary data (bytes/str), not a text/unicode string"
        ) from unicode_error


def get_rsa_private_key(
    private_key: str,
    passphrase: str,
) -> Any:
    encoded_private_key = encode_str_ascii_or_raise(private_key)
    encoded_passphrase = encode_str_ascii_or_raise(passphrase)

    return serialization.load_pem_private_key(
        encoded_private_key,
        password=encoded_passphrase,
        backend=default_backend(),
    )


def create_jwt_assertion(claims: dict, key: JwtKey, options: JwtSignOptions) -> str:
    return jwt.encode(
        {
            'iss': options.issuer,
            'sub': options.subject,
            'box_sub_type': claims['box_sub_type'],
            'aud': options.audience,
            'jti': options.jwtid,
            'exp': claims['exp'],
        },
        get_rsa_private_key(key.key, key.passphrase),
        algorithm=options.algorithm,
        headers={'kid': options.keyid},
    )


Date = datetime.date
DateTime = datetime.datetime


def date_to_string(date: Date) -> str:
    return date.isoformat()


def date_from_string(date: str) -> Date:
    return Date.fromisoformat(date)


def date_time_to_string(date_time: DateTime) -> str:
    return date_time.isoformat().replace('+00:00', 'Z')


def date_time_from_string(date_time: str) -> DateTime:
    return DateTime.fromisoformat(date_time.replace('Z', '+00:00'))


def delay_in_seconds(seconds: int):
    time.sleep(seconds)


def create_null():
    return null
