class NullValue:
    pass


null = NullValue()
